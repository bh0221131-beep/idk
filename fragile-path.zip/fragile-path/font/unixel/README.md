# Unixel | یونیکسل
![example-text](https://github.com/MDarvishi5124/Unixel/assets/100155793/0575b82d-84c6-43d6-b90b-8507da3c25e2)
Unixel is a pixel font inspired by unifont. Although unixel font is a pixel font, special attention has been paid to its beauty and readability in the design department.
Unixel tries to take inspiration from the Arabic script and has largely forgotten the geometric structure.

یونیکسل یک تایپ‎‌فیس پیکسلی است که با الهام زیادی از روی فونت unifont طراحی شده است. با اینکه فونت یونیکسل، یک فونت پیکسلی است، اما در بخش طراحی به زیبایی و خوانایی آن توجه ویژه ای شده است.
یونیکسل سعی دارد از خوشنویسی عربی الهام بگیرد و ساختار هندسی خود را تا حد زیادی فراموش کرده است.


Unixel is currently empty. This means that other features like proper Arabic diacritic will be available in future updates. But now the font is suitable for normal use.

یونیکسل در حال حاضر دست‌خالیست؛ به معنای آنکه قابلیت های دیگر همچون اِعراب‌گذاری مناسب در بروزرسانی های آینده در دسترس قرار خواهد گرفت. اما اکنون فونت برای استفاده های عادی مناسب است.


<a id="download" href="https://github.com/MDarvishi5124/Unixel/releases/tag/1.0">
بارگیری فونت
</a>
